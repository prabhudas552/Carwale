﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public interface Calculator<T>
    {
        T Add(T a, T b);
        T Sub(T a, T b);
        T Div(T a, T b);
        T Mul(T a, T b);
    }



    public class Integer : Calculator<int>
    {
        public int Add(int a, int b)
        {
            return a + b;
        }


        public int Sub(int a, int b)
        {
            return a - b;
        }
        public int Div(int a, int b)
        {

            return a / b;
        }
        public int Mul(int a, int b)
        {
            return a * b;
        }
    }

    public class String1 : Calculator<string>
    {
        public string Add(string a, string b)
        {

            StringBuilder sb = new StringBuilder(a);

            sb.AppendLine(b);

            System.Console.WriteLine(sb.ToString());

            System.Console.ReadLine();


            return sb.ToString();
        }

        public string Sub(string a, string b)
        {
            string c = "";

            if ((string.Compare(a, b)) < 0)
            {
                c = "string a is smaller than string b";
            }
            else if ((string.Compare(a, b)) > 0)
            {
                c = "string a is more than string b";
            }
            else if ((string.Compare(a, b)) == 0)
            {
                c = "string a is equal to string b";
            }

            return c;
        }

        public string Div(string a, string b)
        {

            string myString = a.Remove(a.IndexOf(b), b.Length);
            return myString;
            
        }

        public string Mul(string a, string b)
        {
            int i = 0;
            StringBuilder sb = new StringBuilder();
           string str = "";

           for (i = 0; i < b.Length; i++)
            {

                str=sb.Append(a).Append(b[i]).ToString();
               
                 
            }
          
            return str;
        }


        class Program
        {
            static void Main(string[] args)
            {

                string a, b, res1;
                int c, d, res2;
               
                
                    
                Integer add = new Integer();
                Console.WriteLine("Operands Type:\n");
                Console.WriteLine("1. INTEGER\n");
                Console.WriteLine("2.STRING\n");
                Console.WriteLine("3.BINARY\n");
                Console.WriteLine("Please enter your choice:");

                int i = int.Parse(System.Console.ReadLine());
                Console.Write("Which operation do u want to perform\n");
                Console.Write("1.Additon\n");
                Console.Write("2.Subtraction\n");
                Console.Write("3.Multiplication\n");
                Console.Write("4.Division\n");
                int j = int.Parse(System.Console.ReadLine());
               
                    switch (i)
                    {
                        case 1://Integer operations
                            Console.Write("enter the first number\n");
                            c = int.Parse(System.Console.ReadLine());
                            Console.Write("enter the second number\n");
                            d = int.Parse(System.Console.ReadLine());



                            switch (j)
                            {
                                case 1: res2 = add.Add(c, d);
                                    Console.WriteLine("The Sum is:", res2);
                                    Console.WriteLine(res2);
                                    Console.ReadLine();
                                    break;
                                case 2: res2 = add.Sub(c, d);
                                    Console.WriteLine("The result is:", res2);
                                    break;
                                case 3: res2 = add.Mul(c, d);
                                    Console.WriteLine("The result is:", res2);
                                    break;
                                case 4:
                                    try
                                    {
                                        res2 = add.Div(c, d);
                                        Console.WriteLine("The result is:");
                                        Console.WriteLine(res2);
                                        Console.Read();
                                    }
                                    catch (DivideByZeroException e)
                                    {
                                        Console.WriteLine("Exception caught: {0}", e);
                                        Console.Read();
                                    }
                                    finally
                                    {
                                        Console.WriteLine("Here's your answer!");
                                        Console.Read();
                                    }

                                    break;
                                default:
                                    Console.WriteLine("Do not match any option");
                                    break;

                            }

                            break;
                        case 2://String Manipulation
                            Console.Write("enter the first string\n");
                            a = Console.ReadLine();
                            Console.Write("enter the second string\n");
                            b = Console.ReadLine();
                            String1 str = new String1();
                            switch (j)
                            {
                                case 1: res1 = str.Add(a, b);
                                    Console.WriteLine("The concatenated string is: {0}", res1);
                                    Console.Read();
                                    break;
                                case 2: res1 = str.Sub(a, b);
                                    Console.WriteLine(res1);
                                    Console.Read();
                                    break;
                                case 3: res1 = str.Mul(a, b);
                                    Console.WriteLine("The multiplication of the input strings is:\t {0}", res1);
                                    Console.Read();
                                    break;
                                case 4: res1 = str.Div(a, b);
                                    Console.WriteLine(res1);
                                    Console.Read();
                                    break;


                                default:
                                    Console.WriteLine("Do not match any option");
                                    Console.Read();
                                    break;

                            }

                            break;
                        case 3:// Binary operations

                            Console.Write("enter the first binary number\n");
                            int num1 = Convert.ToInt32(Console.ReadLine(), 2);
                            Console.Write("enter the second binary number\n");
                            int num2 = Convert.ToInt32(Console.ReadLine(), 2);



                            switch (j)
                            {

                                case 1: res2 = add.Add(num1, num2);
                                    Console.WriteLine("The Sum is:");
                                    Console.WriteLine(Convert.ToString(res2, 2));
                                    Console.ReadLine();
                                    break;
                                case 2: res2 = add.Sub(num1, num2);
                                    Console.WriteLine("The result is:");
                                    Console.WriteLine(Convert.ToString(res2, 2));
                                    Console.ReadLine();
                                    break;
                                case 3: res2 = add.Mul(num1, num2);
                                    Console.WriteLine("The result is:");
                                    Console.ReadLine();
                                    Console.WriteLine(Convert.ToString(res2, 2));
                                    Console.ReadLine();
                                    break;
                                case 4: res2 = add.Div(num1, num2); ;
                                    Console.WriteLine("The result is:");
                                    Console.WriteLine(Convert.ToString(res2, 2));
                                    Console.ReadLine();
                                    break;
                                default:
                                    Console.WriteLine("Do not match any option");
                                    break;

                            }
                            break;
                        default:
                            Console.WriteLine("Do not match any option");
                            break;
                    }
                

            }
        }
    }
}
     
    
    






        