﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator11
{
    public interface Icalculator<T>
    {
        T add(T val_1, T val_2);
        T sub(T val_1, T val_2);
        T mul(T val_1, T val_2);
        T div(T val_1, T val_2);
        void set();
        void call();
    }
    public class binarY : Icalculator<string>
    {
        public string x;
        public string y;
        public void set()
        {
            Console.WriteLine("Enter first value and second value");
            x = (Console.ReadLine());
            y = (Console.ReadLine());

        }
        public void call()
        {

            set();
            Console.WriteLine("Enter 1 for addition Enter 2 for subtraction and Enter 3 for smultiplication Enter 4 for division");
            int input1 = Convert.ToInt32(Console.ReadLine());


            switch (input1)
            {
                case 1: Console.WriteLine(add(x, y));
                    Console.ReadLine();
                    break;
                case 2: Console.WriteLine(sub(x, y));
                    Console.ReadLine();
                    break;

                case 3: Console.WriteLine(mul(x, y));
                    Console.ReadLine();
                    break;
                case 4: Console.WriteLine(div(x, y));
                    Console.ReadLine();
                    break;
                default: Console.WriteLine("invalid");
                    break;

            }

        }
        public string add(string a1, string b1)
        {
            int x, y;
           
            x = Convert.ToInt32(a1, 2);
            y = Convert.ToInt32(b1, 2);
        
            return Convert.ToString(x + y, 2);
        }

        public string sub(string a1, string b1)
        {
            int x, y;
            x = Convert.ToInt32(a1, 2);
            y = Convert.ToInt32(b1, 2);
            if (x < y)
            {
                return Convert.ToString(y - x, 2);
            }
            return Convert.ToString(x - y, 2);

        }

        public string mul(string a1, string b1)
        {
            int x, y;
            x = Convert.ToInt32(a1, 2);
            y = Convert.ToInt32(b1, 2);

            return Convert.ToString(x * y, 2);
        }

        public string div(string a1, string b1)
        {
            int x, y;
            x = Convert.ToInt32(a1, 2);
            y = Convert.ToInt32(b1, 2);


            return Convert.ToString(x / y, 2);
        }
    }
    public class strinG : Icalculator<string>
    {
        public string x;
        public string y;
        public void set()
        {
            Console.WriteLine("Enter first value and second value if string multiplication to be done enter second value to be numeric");
            x = (Console.ReadLine());
          y 
              = (Console.ReadLine());

        }
        public void call()
        {

            set();
            Console.WriteLine("Enter 1 for addition Enter 2 for subtraction and Enter 3 for smultiplication Enter 4 for division");
            int input1 = Convert.ToInt32(Console.ReadLine());


            switch (input1)
            {
                case 1: Console.WriteLine(add(x, y));
                    Console.ReadLine();
                    break;
                case 2: Console.WriteLine(sub(x, y));
                    Console.ReadLine();
                    break;

                case 3: Console.WriteLine(mul(x, y));
                    Console.ReadLine();
                    break;
                case 4: Console.WriteLine(div(x, y));
                    Console.ReadLine();
                    break;
                default: Console.WriteLine("invalid");
                    break;

            }

        }
        public string add(string string1, string string2)
        {
            return string.Concat(string1, string2);
        }


        public string mul(string string1, string string2)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Convert.ToInt32(string2); i++)
            {
                sb.Append(string1);
            }

            return sb.ToString();
        }
        public string sub(string string1, string string2)
        {

            string result = string1.Remove(string1.IndexOf(string2), string2.Length);
            return result;

        }
        public string div(string string1, string string2)
        {

            string result = string1.Remove(string1.IndexOf(string2), string2.Length);
            return result;
           

        }



    }

    public class decimaL : Icalculator<int>
    {
        public int x;
        public int y;
        public void set()
        {
            Console.WriteLine("Enter first value and second value");
            x = Convert.ToInt32(Console.ReadLine());
            y = Convert.ToInt32(Console.ReadLine());

        }
        public void call()
        {

            set();
            Console.WriteLine("Enter 1 for addition Enter 2 for subtraction and Enter 3 for smultiplication Enter 4 for division");
            int input1 = Convert.ToInt32(Console.ReadLine());


            switch (input1)
            {
                case 1: Console.WriteLine(add(x, y));
                    Console.ReadLine();
                    break;
                case 2: Console.WriteLine(sub(x, y));
                    Console.ReadLine();
                    break;

                case 3: Console.WriteLine(mul(x, y));
                    Console.ReadLine();
                    break;
                case 4: Console.WriteLine(div(x, y));
                    Console.ReadLine();
                    break;
                default: Console.WriteLine("invalid");
                    break;

            }

        }
        public int add(int x, int y)
        {
            return x + y;
        }
        public int sub(int x, int y)
        {
            return x - y;
        }
        public int mul(int x, int y)
        {
            return (x * y);
        }
        public int div(int x, int y)
        {
            return x / y;
        }
    }
    public class Class1
    {
        public static void Main()
        {
            Console.WriteLine("Enter 1 for decimal calculation Enter 2 for Binary calculation and enter 3 for string calculation");
            int input = Convert.ToInt32(Console.ReadLine());


            switch (input)
            {
                case 1: decimaL obj = new decimaL();
                    obj.call();
                    break;
                case 2: binarY obj1 = new binarY();

                    obj1.call();
                    break;
                case 3: strinG obj2 = new strinG();
                    obj2.call();
                    break;
                default: Console.WriteLine("invalid");
                    break;

            }
        }
    }
}
