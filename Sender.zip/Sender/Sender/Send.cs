﻿using System;
using System.Linq;
using RabbitMQ.Client;
using System.Text;

class EmitLogDirect
{
    public static void Main(string[] args)
    {
       // string url = @"amqp://kxqfztha:PatbPh8Qi804fkzGfPjgXsPagudg4LUm@white-mynah-bird.rmq.cloudamqp.com/kxqfztha";
        var factory = new ConnectionFactory() { HostName = "172.16.8.3" };
       // factory.Uri = url;
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.ExchangeDeclare(exchange: "topic",
                                    type: "direct");

            var severity = "info";
            while (true)
            {
                var message = Console.ReadLine();
                var body = Encoding.UTF8.GetBytes(message);
                channel.BasicPublish(exchange: "topic",
                                     routingKey: severity,
                                     basicProperties: null,
                                     body: body);
                Console.WriteLine(" [x] Sent '{0}':'{1}'", severity, message);
            }
        }

        Console.WriteLine(" Press [enter] to exit.");
        Console.ReadLine();
    }
}