﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class Recevie2
    {
        public static void Main(string[] args)
        {
           // string url = @"amqp://kxqfztha:PatbPh8Qi804fkzGfPjgXsPagudg4LUm@white-mynah-bird.rmq.cloudamqp.com/kxqfztha";
            var factory = new ConnectionFactory() { HostName = "172.16.8.3" };
            //factory.Uri = url;
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: "topic",
                                        type: "direct");
                var queueName = channel.QueueDeclare().QueueName;




                channel.QueueBind(queue: queueName,
                                  exchange: "topic",
                                  routingKey: "info");
                channel.QueueBind(queue: queueName,
                                  exchange: "topic",
                                  routingKey: "info1");



                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body;
                    var message = Encoding.UTF8.GetString(body);
                    var routingKey = ea.RoutingKey;
                    Console.WriteLine(" [x] Received '{0}':'{1}'",
                                      routingKey, message);
                };
                channel.BasicConsume(queue: queueName,
                                     noAck: true,
                                     consumer: consumer);

                Console.WriteLine(" Press [enter] to exit.");
                Console.ReadLine();
            }
        }
    }

