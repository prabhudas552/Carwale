﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class singlesender
    {
        public static void Main(string[] args)
        {
            //string url = @"amqp://kxqfztha:PatbPh8Qi804fkzGfPjgXsPagudg4LUm@white-mynah-bird.rmq.cloudamqp.com/kxqfztha";
            var factory = new ConnectionFactory() { HostName = "172.16.8.3" };
            //factory.Uri = url;
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: "topic",
                                        type: "direct");

                var sub = "info1";
                while (true)
                {
                    var message = Console.ReadLine();
                    var body = Encoding.UTF8.GetBytes(message);
                    channel.BasicPublish(exchange: "topic",
                                         routingKey: sub,
                                         basicProperties: null,
                                         body: body);
                    Console.WriteLine(" [x] Sent '{0}':'{1}'", sub, message);
                }
            }

            Console.WriteLine(" Press [enter] to exit.");
            Console.ReadLine();
        }
    }

